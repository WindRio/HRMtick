package com.example.base_projecthrm_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseProjectHrmJavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
