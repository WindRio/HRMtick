package com.example.base_projecthrm_java.services.servicesOtp;

import com.example.base_projecthrm_java.jwt.JwtUntility;
import com.example.base_projecthrm_java.mail.MailServices;
import com.example.base_projecthrm_java.mail.OTP;
import com.example.base_projecthrm_java.model.modelAuthen.dto.response.ResponseLogin;
import com.example.base_projecthrm_java.model.modelAuthen.entity.EntityAccount;
import com.example.base_projecthrm_java.model.modelAuthen.mapper.MapperAuthen;
import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestCreateOtp;
import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestSendOtp;
import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestSendOtpChangePassword;
import com.example.base_projecthrm_java.model.response.Responses;
import com.example.base_projecthrm_java.reponsitory.reponsitoryAuthen.RepositoryAccount;
import com.example.base_projecthrm_java.services.servicesAuthen.ServicesAuthenImp;
import com.example.base_projecthrm_java.utils.responseString.ResponseString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ServicesOtpImp implements ServiceOtp {

//    private JavaMailSender javaMailSender;
    @Autowired
    private JwtUntility jwtUntility;
    @Autowired
    private MailServices mailServices;
    @Autowired
    private RepositoryAccount reponsitoryAccount;
    @Autowired
    private ServicesAuthenImp servicesAuthenImp;


        @Override
    public Responses sendOtpRegister(RequestSendOtp requestSendOtp) {
            EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(requestSendOtp.getEmail());
            if (entityAccount==null){
                return new Responses(true, ResponseString.otp.WRONG_EMAIL);
            }
            if (entityAccount.getOtp().equals(requestSendOtp.getOtp())==false){
                return new Responses(false,ResponseString.otp.OTP_FAILURE);
            }
            entityAccount.setActive(true);
            entityAccount.setOtp(null);
            reponsitoryAccount.save(entityAccount);

        return new Responses(true, ResponseString.register.REGISTER_SUCCESS);
    }

    @Override
    public Responses createOtp(RequestCreateOtp requestCreateOtp) {
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(requestCreateOtp.getEmail());
        if (entityAccount==null){
            return new Responses(true, ResponseString.otp.WRONG_EMAIL);
        }
        Integer Otp =OTP.createOtp();
        entityAccount.setOtp(Otp);
        reponsitoryAccount.save(entityAccount);
        return mailServices.sendEmail(requestCreateOtp.getEmail(),Otp );
    }

    @Override
    public Responses sendOtpLogin(RequestSendOtp requestSendOtp) {
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(requestSendOtp.getEmail());
        if (entityAccount==null){
            return new Responses(false, ResponseString.otp.WRONG_EMAIL);
        }
        if (entityAccount.isActive() == false){
            return  new Responses(false,ResponseString.Login.WRONG_ACCOUNT);
        }
        if (entityAccount.getOtp().equals(requestSendOtp.getOtp())==false){
            return new Responses(false,ResponseString.otp.OTP_FAILURE);
        }
//        entityAccount.setOtp(null);
//        reponsitoryAccount.save(entityAccount);
        String token = jwtUntility.createJwtToken(entityAccount.getEmail());
        ResponseLogin dtoLogin = MapperAuthen.mapEntityAccount_DtoLogin(entityAccount,token);

        return new Responses(true,ResponseString.Login.LOGIG_SUCCESS,dtoLogin);
    }

    @Override
    public Responses sendOtpChangePassword(RequestSendOtpChangePassword requestSendOtpChangePassword) {
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(requestSendOtpChangePassword.getEmail());
        if (entityAccount==null){
            return new Responses(true, ResponseString.otp.WRONG_EMAIL);
        }
        if (entityAccount.getOtp().equals(requestSendOtpChangePassword.getOtp())==false){
            return new Responses(false,ResponseString.otp.OTP_FAILURE);
        }
        entityAccount.setOtp(null);
        reponsitoryAccount.save(entityAccount);
        Responses response = servicesAuthenImp.changePassword(entityAccount.getEmail(),requestSendOtpChangePassword.getPassword());
        return new Responses(response.isStatus(),response.getMessage());
    }
}
