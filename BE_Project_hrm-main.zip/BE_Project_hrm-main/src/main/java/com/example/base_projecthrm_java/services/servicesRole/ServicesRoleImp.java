package com.example.base_projecthrm_java.services.servicesRole;


import com.example.base_projecthrm_java.model.modelPermission.entity.EntityPermission;
import com.example.base_projecthrm_java.model.modelRole.dto.response.ResponseRole;
import com.example.base_projecthrm_java.model.modelRole.entity.EntityRole;
import com.example.base_projecthrm_java.model.modelRole.mapper.MapperRole;
import com.example.base_projecthrm_java.model.modelRole.dto.request.RequestRole;
import com.example.base_projecthrm_java.model.response.Responses;
import com.example.base_projecthrm_java.reponsitory.reponsitoryPermission.RepositoryPermission;
import com.example.base_projecthrm_java.reponsitory.reponsitoryRole.RepositoryRole;
import com.example.base_projecthrm_java.utils.responseString.ResponseString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class ServicesRoleImp implements ServiceRole{

    @Autowired
    private RepositoryRole reponsitoryRole;
    @Autowired
    private RepositoryPermission reponsitoryPermission;
    @Override
    public Responses searchPaginationRole(String text, Integer page, Integer limit) {
        Pageable pageable = PageRequest.of(page, limit);
        Page<EntityRole> listPage = reponsitoryRole.findByNameContaining(text, pageable);
        List<ResponseRole> listRole = listPage.stream().map(MapperRole::mapEntityRole).collect(Collectors.toList());
        if (listRole.isEmpty()){
            return new Responses(false, ResponseString.WRONG_LIST);
        }else {
            return new Responses(true, ResponseString.SUCCESS, listRole, listPage.getTotalPages());
        }
    }

    @Override
    public Responses getAllRole() {
        List<ResponseRole> listRole = reponsitoryRole.findAll().stream().map(MapperRole::mapEntityRole).collect(Collectors.toList());
        if (listRole.isEmpty()){
            return new Responses(false, ResponseString.WRONG_LIST);
        }else {
            return new Responses(true, ResponseString.SUCCESS, listRole);
        }
    }

    @Override
    public Responses addRole(RequestRole requestRole) {
        EntityRole checkEntityRole = reponsitoryRole.findEntityRoleByName(requestRole.getName());
        if (checkEntityRole != null)return new Responses(false,ResponseString.WRONG_NAME);
        EntityRole entityRole = MapperRole.mapRequestRole(requestRole);
        if (requestRole.getListIdPermission() !=null){
            for (Integer id:requestRole.getListIdPermission()) {
                EntityPermission entityPermission = reponsitoryPermission.findEntityPermissionById(id);
                entityRole.getListPermission().add(entityPermission);
            }
        }
        reponsitoryRole.save(entityRole);
        return new Responses(true, ResponseString.SUCCESS, entityRole);
    }

    @Override
    public Responses updateRole(RequestRole requestRole,Integer id) {
        EntityRole entityRole = reponsitoryRole.findEntityRoleById(id);
        if (entityRole == null)return new Responses(false,ResponseString.WRONG_ID);
       entityRole.setName(requestRole.getName());
        if (requestRole.getListIdPermission() !=null){
            Set<EntityPermission> listNew = new HashSet<>() ;
            for (Integer idPermission:requestRole.getListIdPermission()) {
                EntityPermission entityPermission = reponsitoryPermission.findEntityPermissionById(idPermission);
                if (entityPermission != null) listNew.add(entityPermission);
            }
            entityRole.setListPermission(listNew);
        }
        reponsitoryRole.save(entityRole);
        return new Responses(true, ResponseString.SUCCESS, entityRole);
    }

    @Override
    public Responses deleteRole(Integer id) {
        EntityRole entityRole = reponsitoryRole.findEntityRoleById(id);
        if (entityRole == null)return new Responses(false,ResponseString.WRONG_ID);
        reponsitoryRole.deleteById(id);
        return new Responses(true, ResponseString.SUCCESS, entityRole);
    }
}
