package com.example.base_projecthrm_java.reponsitory.reponsitoryPermission;

import com.example.base_projecthrm_java.model.modelPermission.entity.EntityPermission;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RepositoryPermission extends JpaRepository<EntityPermission,Integer> {
    List<EntityPermission> findAll();
    EntityPermission findEntityPermissionByName(String name);
    EntityPermission findEntityPermissionById(Integer id);
    Page<EntityPermission> findByNameContaining(String text, Pageable pageable);
}
