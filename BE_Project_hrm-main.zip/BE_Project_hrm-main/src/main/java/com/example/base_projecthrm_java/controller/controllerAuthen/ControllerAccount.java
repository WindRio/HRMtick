package com.example.base_projecthrm_java.controller.controllerAuthen;

import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestAccount;
import com.example.base_projecthrm_java.services.servicesAuthen.servicesAccount.ServiceAccount;
import com.example.base_projecthrm_java.utils.apiContants.ApiContants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@CrossOrigin("*")
@RequestMapping(ApiContants.Account)
public class ControllerAccount {
    @Autowired
    private ServiceAccount serviceAccount;
    @PutMapping("{id}")
    ResponseEntity<?>updateAccountRole(@RequestBody RequestAccount requestAccount,@PathVariable Integer id){
        return ResponseEntity.status(HttpStatus.OK).body(serviceAccount.updateAccountRole(requestAccount,id));
    }
    @GetMapping()
    ResponseEntity<?> searchPaginationAccount(@RequestParam(name = "textSearch",defaultValue = "")String text,
                                           @RequestParam(name = "activePage",defaultValue = "0")Integer page,
                                           @RequestParam(name = "limit",defaultValue = "2")Integer limit){
        return ResponseEntity.status(HttpStatus.OK).body(serviceAccount.searchPaginationAccount(text,page,limit));
    }
}
