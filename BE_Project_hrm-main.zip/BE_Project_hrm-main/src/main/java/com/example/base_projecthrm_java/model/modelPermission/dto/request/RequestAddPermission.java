package com.example.base_projecthrm_java.model.modelPermission.dto.request;


import lombok.Data;

@Data
public class RequestAddPermission {
    private String name;
    private String description;

}
