package com.example.base_projecthrm_java.services.servicesProfile;

import com.example.base_projecthrm_java.model.modelProfile.Dto.request.RequestProfile;
import com.example.base_projecthrm_java.model.modelProfile.Dto.response.ResponseProfile;
import com.example.base_projecthrm_java.model.modelProfile.entity.EntityProfile;
import com.example.base_projecthrm_java.model.modelProfile.mapper.MapperProfile;
import com.example.base_projecthrm_java.model.response.Responses;
import com.example.base_projecthrm_java.reponsitory.reponsitoryProfile.RepositoryProfile;
import com.example.base_projecthrm_java.utils.responseString.ResponseString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ServicesProfileImp implements ServiceProfile{
    @Autowired
    private RepositoryProfile reponsitoryProfile;
    @Override
    public Responses updateProfile(RequestProfile requestProfile,Integer id) {
        EntityProfile entityProfile = reponsitoryProfile.findEntityProfileById(id);
        if (entityProfile == null)return  new Responses(false, ResponseString.WRONG_ID);
        if (requestProfile.getAddress() != null)entityProfile.setAddress(requestProfile.getAddress());
        if (requestProfile.getFullName() != null)entityProfile.setFullName(requestProfile.getFullName());
        if (requestProfile.getGender() != null)entityProfile.setGender(requestProfile.getGender());
        if (requestProfile.getBirthday() != null)entityProfile.setBirthday(requestProfile.getBirthday());
        if (requestProfile.getPhone() != null)entityProfile.setPhone(requestProfile.getPhone());
        reponsitoryProfile.save(entityProfile);
        return new Responses(true,ResponseString.SUCCESS);
    }

    @Override
    public Responses getById(Integer id) {
        EntityProfile entityProfile = reponsitoryProfile.findEntityProfileById(id);
        if (entityProfile == null)return  new Responses(false, ResponseString.WRONG_ID);
        ResponseProfile responseProfile = MapperProfile.mapEntityProfile(entityProfile);

        return new Responses(true,ResponseString.SUCCESS,responseProfile);
    }
}
