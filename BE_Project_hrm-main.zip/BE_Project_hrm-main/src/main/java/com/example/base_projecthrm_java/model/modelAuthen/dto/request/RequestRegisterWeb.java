package com.example.base_projecthrm_java.model.modelAuthen.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestRegisterWeb {
    private String email;
    private String password;
    private Set<Integer> listIdRole = new HashSet<>();

}
