package com.example.base_projecthrm_java.model.modelProfile.entity;

import com.example.base_projecthrm_java.model.modelAuthen.entity.EntityAccount;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "profile")
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "id")
public class EntityProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "full_name")
    private String fullName;
    @Column(name = "phone")
    private Integer phone;
    @Column
    private String gender;
    @Column(name = "referral_code", unique = true)
    private Integer referralCode;
    @Column(name = "presenter")
    private Integer presenterCode;
    @Column(name = "address")
    private String address;
    @Column(name = "birthday")
    private Date birthday;
    @OneToOne()
//    @JsonManagedReference
    @JoinColumn(name = "id_account_presenter")
    private EntityAccount accountPresenter;
    @OneToOne()
    @JoinColumn(name = "id_account")
    private EntityAccount account;

    public EntityProfile(String fullName, Integer phone, String address, Date birthday) {
        this.fullName = fullName;
        this.phone = phone;
        this.address = address;
        this.birthday = birthday;
    }

    public EntityProfile(String full_name, Integer phone) {
        this.fullName = full_name;
        this.phone = phone;
    }

    public EntityProfile(Integer id) {
        this.id = id;
    }
}
