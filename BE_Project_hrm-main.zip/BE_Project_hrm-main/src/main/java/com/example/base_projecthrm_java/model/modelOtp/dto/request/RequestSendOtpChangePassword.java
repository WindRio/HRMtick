package com.example.base_projecthrm_java.model.modelOtp.dto.request;

import lombok.Data;

@Data
public class RequestSendOtpChangePassword {
    private String email;
    private Integer otp;
    private String password;
}
