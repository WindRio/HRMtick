package com.example.base_projecthrm_java.model.modelAuthen.dto.request;

import lombok.Data;

@Data
public class ChangePassword {
    private String email;
    private String password;
    private String password_new;
}
