package com.example.base_projecthrm_java.services.servicesRole;


import com.example.base_projecthrm_java.model.modelRole.dto.request.RequestRole;
import com.example.base_projecthrm_java.model.response.Responses;
import org.springframework.stereotype.Service;

@Service
public interface ServiceRole {
    Responses searchPaginationRole(String text, Integer page , Integer limit);
    Responses getAllRole();
    Responses addRole(RequestRole requestRole);
    Responses updateRole(RequestRole requestRole,Integer id);
    Responses deleteRole(Integer id);
}
