package com.example.base_projecthrm_java.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Responses {
    private boolean status;
    private String message;
    private Object data;
    private Integer totalPage;

    public Responses(boolean status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public Responses(boolean status, String message) {
        this.status = status;
        this.message = message;
    }

    public Responses(boolean status) {
        this.status = status;
    }
}
