package com.example.base_projecthrm_java.controller.controllerPassword;

import com.example.base_projecthrm_java.model.modelAuthen.dto.request.ChangePassword;
import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestForgotPassword;
import com.example.base_projecthrm_java.services.servicesAuthen.serviceAuthen;
import com.example.base_projecthrm_java.utils.apiContants.ApiContants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
@CrossOrigin("*")

public class ControllerPassword {
    @Autowired
    private serviceAuthen serviceAuthen;
    @PreAuthorize("hasRole('User')")
    @PostMapping(ApiContants.Password.CHANGEPASSWORDLOGIN)
    ResponseEntity<?> ChangePasswordLogin(@RequestBody ChangePassword changePassword){
        return ResponseEntity.status(HttpStatus.OK).body(serviceAuthen.changePasswordLogin(changePassword));
    }
    @PostMapping(ApiContants.Password.FORGOTPASSWORD)
    ResponseEntity<?>forgotPassword(@RequestBody RequestForgotPassword requestforgotPassword){
        return ResponseEntity.status(HttpStatus.OK).body(serviceAuthen.forgotPassword(requestforgotPassword));
    }
}
