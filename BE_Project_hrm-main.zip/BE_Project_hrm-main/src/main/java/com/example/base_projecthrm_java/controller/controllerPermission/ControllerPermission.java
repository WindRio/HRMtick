package com.example.base_projecthrm_java.controller.controllerPermission;

import com.example.base_projecthrm_java.model.modelPermission.dto.request.RequestAddPermission;
import com.example.base_projecthrm_java.model.modelPermission.dto.request.RequestUpdatePermission;
import com.example.base_projecthrm_java.services.servicesPermission.ServicePermission;
import com.example.base_projecthrm_java.utils.apiContants.ApiContants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@CrossOrigin("*")
@RequestMapping(ApiContants.Permission)
public class ControllerPermission {
    @Autowired
    private ServicePermission servicePermission;
    @GetMapping(ApiContants.getAll)
    ResponseEntity<?> getAllPermission(){
        return ResponseEntity.status(HttpStatus.OK).body(servicePermission.getAllPermission());
    }
    @PostMapping()
    ResponseEntity<?>addPermission(@RequestBody RequestAddPermission requestPermission){
        return ResponseEntity.status(HttpStatus.OK).body(servicePermission.addPermission(requestPermission));
    }
    @PutMapping("{id}")
    ResponseEntity<?>updatePermission(@RequestBody RequestUpdatePermission requestUpdatePermission,
                                      @PathVariable Integer id
    ){
        return ResponseEntity.status(HttpStatus.OK).body(servicePermission.updatePermission(requestUpdatePermission ,id));
    }
    @DeleteMapping ("{id}")
    ResponseEntity<?>deletePermission(@PathVariable Integer id){
        return ResponseEntity.status(HttpStatus.OK).body(servicePermission.deletePermission(id));
    }
    @GetMapping()
    ResponseEntity<?>searchPagination(@RequestParam(name = "textSearch",defaultValue = "")String text,
                                      @RequestParam(name = "activePage",defaultValue = "0")Integer page,
                                      @RequestParam(name = "limit",defaultValue = "2")Integer limit){
        return ResponseEntity.status(HttpStatus.OK).body(servicePermission.searchPaginationPermission(text,page,limit));
    }
}
