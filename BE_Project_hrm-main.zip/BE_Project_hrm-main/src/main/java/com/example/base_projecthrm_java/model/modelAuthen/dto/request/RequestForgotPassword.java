package com.example.base_projecthrm_java.model.modelAuthen.dto.request;

import lombok.Data;

@Data
public class RequestForgotPassword {
    private String email;
}
