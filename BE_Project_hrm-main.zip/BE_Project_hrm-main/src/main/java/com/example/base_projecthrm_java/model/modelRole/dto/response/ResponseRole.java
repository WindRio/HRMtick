package com.example.base_projecthrm_java.model.modelRole.dto.response;

import com.example.base_projecthrm_java.model.modelPermission.entity.EntityPermission;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseRole {
    private Integer id;
    private  String name;
    private Set<EntityPermission> listPermission = new HashSet<>();
}
