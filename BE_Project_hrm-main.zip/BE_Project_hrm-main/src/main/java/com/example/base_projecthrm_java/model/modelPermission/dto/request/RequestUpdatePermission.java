package com.example.base_projecthrm_java.model.modelPermission.dto.request;

import lombok.Data;

@Data
public class RequestUpdatePermission {
    private String description;
}
