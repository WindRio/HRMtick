package com.example.base_projecthrm_java.reponsitory.reponsitoryAuthen;

import com.example.base_projecthrm_java.model.modelAuthen.entity.EntityAccount;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositoryAccount extends JpaRepository<EntityAccount,Integer > {
    EntityAccount findEntityAccountByEmail(String email);
    EntityAccount findEntityAccountById(Integer id);
    @Query(value = "SELECT * FROM account join profile on profile.id = account.profile_id where profile.referral_code = ?1",nativeQuery = true)
    EntityAccount findEntityAccountByReferral_code(Integer number);

    Page<EntityAccount> findByEmailContaining(String text, Pageable pageable);
}
