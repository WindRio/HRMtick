package com.example.base_projecthrm_java.model.modelOtp.dto.request;

import lombok.Data;

@Data
public class RequestSendOtp {
    private String email;
    private Integer otp;
}
