package com.example.base_projecthrm_java.utils.apiContants;


public interface ApiContants {
    String otp ="/otp";
    interface Authen {
        String LOGIN = "/login";
        String REGISTERWEB = "/registerWeb";
        String REGISTERAPP = "/registerApp";
    }
    interface Otp{
        String SENDOTPREGISTER = otp+"/sendOTPRegister";
        String CREATEOTP = otp+"/createOTP";
        String SENDOTPLOGIN = otp+"/sendOTPLogin";
        String SENDOTPCHAGEPASSWORD=otp+"/sendOtpChangePassword";
    }
    interface Password{
        String  CHANGEPASSWORDLOGIN = "/changePasswordLogin";
        String FORGOTPASSWORD = "/forgotPassword";
    }
    String Role ="/role";
    String Permission ="/permission";
    String Account ="/account";
    String getAll = "/getAll";
    String Profile ="/profile";
    String GetById = "/getById";
//    interface Permission{
//        String
//    }
    String Test = "/test";
}

