package com.example.base_projecthrm_java.reponsitory.reponsitoryRole;

import com.example.base_projecthrm_java.model.modelRole.entity.EntityRole;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RepositoryRole extends JpaRepository<EntityRole,Integer> {
    List<EntityRole> findAll();
    EntityRole findEntityRoleByName(String name);
    EntityRole findEntityRoleById(Integer id);
    Page<EntityRole> findByNameContaining(String text, Pageable pageable);
}
