package com.example.base_projecthrm_java.controller.controllerOtp;

import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestCreateOtp;
import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestSendOtp;
import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestSendOtpChangePassword;
import com.example.base_projecthrm_java.services.servicesOtp.ServiceOtp;
import com.example.base_projecthrm_java.utils.apiContants.ApiContants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
@CrossOrigin("*")
public class ControllerOtp {
    @Autowired
    private ServiceOtp serviceOtp;
    @PostMapping(ApiContants.Otp.SENDOTPREGISTER)
    ResponseEntity<?>sendOtpRegister(@RequestBody RequestSendOtp requestSendOtp){
        return  ResponseEntity.status(HttpStatus.OK).body(serviceOtp.sendOtpRegister(requestSendOtp));
    }
    @PostMapping(ApiContants.Otp.CREATEOTP)
    ResponseEntity<?>createOtp(@RequestBody RequestCreateOtp requestCreateOtp){
        return ResponseEntity.status(HttpStatus.OK).body(serviceOtp.createOtp(requestCreateOtp));
    }
    @PostMapping(ApiContants.Otp.SENDOTPLOGIN)
    ResponseEntity<?>sendOtpLogin(@RequestBody RequestSendOtp requestSendOtp){
        return  ResponseEntity.status(HttpStatus.OK).body(serviceOtp.sendOtpLogin(requestSendOtp));
    }
    @PostMapping(ApiContants.Otp.SENDOTPCHAGEPASSWORD)
    ResponseEntity<?>sendOtpChangePassword(@RequestBody RequestSendOtpChangePassword requestSendOtpChangePassword){
        return  ResponseEntity.status(HttpStatus.OK).body(serviceOtp.sendOtpChangePassword(requestSendOtpChangePassword));
    }
}
