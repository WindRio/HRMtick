package com.example.base_projecthrm_java.model.modelRole.dto.request;

import lombok.Data;

import java.util.Set;
@Data
public class RequestRole {
    private Integer id;
    private String name;
    private Set<Integer> listIdPermission;
}
