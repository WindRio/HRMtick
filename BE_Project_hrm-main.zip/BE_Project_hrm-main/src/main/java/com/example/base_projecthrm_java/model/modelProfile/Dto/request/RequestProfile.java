package com.example.base_projecthrm_java.model.modelProfile.Dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.sql.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestProfile {
    private  Integer id;
    private String fullName;
    private Integer phone;
    private String gender;
    private String address;
    private Date birthday;
}
