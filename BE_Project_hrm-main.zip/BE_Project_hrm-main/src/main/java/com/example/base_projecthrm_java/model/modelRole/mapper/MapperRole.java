package com.example.base_projecthrm_java.model.modelRole.mapper;

import com.example.base_projecthrm_java.model.modelRole.dto.response.ResponseRole;
import com.example.base_projecthrm_java.model.modelRole.entity.EntityRole;
import com.example.base_projecthrm_java.model.modelRole.dto.request.RequestRole;

public class MapperRole {
    public static ResponseRole mapEntityRole(EntityRole entityRole){
        ResponseRole dtoRole = new ResponseRole(entityRole.getId(), entityRole.getName(), entityRole.getListPermission());
        return dtoRole;
    }
    public static EntityRole mapRequestRole(RequestRole requestRole){
        EntityRole entityRole = new EntityRole();
        entityRole.setName(requestRole.getName());
        return entityRole;
    }
}
