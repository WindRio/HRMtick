package com.example.base_projecthrm_java.services.servicesProfile;

import com.example.base_projecthrm_java.model.modelProfile.Dto.request.RequestProfile;
import com.example.base_projecthrm_java.model.response.Responses;
import org.springframework.stereotype.Service;

@Service
public interface ServiceProfile {
    Responses updateProfile(RequestProfile requestProfile,Integer id);
    Responses getById(Integer id);
}
