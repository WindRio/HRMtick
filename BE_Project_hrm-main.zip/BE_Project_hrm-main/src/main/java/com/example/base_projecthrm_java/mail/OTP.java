package com.example.base_projecthrm_java.mail;

public class OTP {
    public static Integer createOtp(){
        double randomDouble = Math.random()*1_000_000f;
        return (int)randomDouble;
    }
}
