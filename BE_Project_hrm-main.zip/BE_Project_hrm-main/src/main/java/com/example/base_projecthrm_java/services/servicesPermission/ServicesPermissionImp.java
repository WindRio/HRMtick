package com.example.base_projecthrm_java.services.servicesPermission;

import com.example.base_projecthrm_java.model.modelPermission.dto.response.ResponsePermission;
import com.example.base_projecthrm_java.model.modelPermission.entity.EntityPermission;
import com.example.base_projecthrm_java.model.modelPermission.mapper.MapperPermission;
import com.example.base_projecthrm_java.model.modelPermission.dto.request.RequestAddPermission;
import com.example.base_projecthrm_java.model.modelPermission.dto.request.RequestUpdatePermission;
//import com.example.base_projecthrm_java.model.modelPermission.response.ResponsePermission;
import com.example.base_projecthrm_java.model.response.Responses;
import com.example.base_projecthrm_java.reponsitory.reponsitoryPermission.RepositoryPermission;
import com.example.base_projecthrm_java.utils.responseString.ResponseString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ServicesPermissionImp implements ServicePermission{
    @Autowired
    private RepositoryPermission reponsitoryPermission;

    @Override
    public Responses getAllPermission() {
        List<ResponsePermission> productDtos = reponsitoryPermission.findAll().stream().map(MapperPermission::mapEntityPermission).collect(Collectors.toList());
        if (productDtos.isEmpty()){
            return new Responses(false, ResponseString.WRONG_LIST);
        }else {
            return new Responses(true, ResponseString.SUCCESS, productDtos);
        }
    }

    @Override
    public Responses searchPaginationPermission(String text, Integer page, Integer limit) {
        Pageable pageable = PageRequest.of(page, limit);
        Page<EntityPermission> listPage = reponsitoryPermission.findByNameContaining(text, pageable);
        List<ResponsePermission> productDtos = listPage.stream().map(MapperPermission::mapEntityPermission).collect(Collectors.toList());
        if (productDtos.isEmpty()){
            return new Responses(false, ResponseString.WRONG_LIST);
        }else {
            return new Responses(true, ResponseString.SUCCESS, productDtos, listPage.getTotalPages());
        }
    }

    @Override
    public Responses addPermission(RequestAddPermission requestPermission) {
        EntityPermission entityPermission = MapperPermission.mapRequestPermission(requestPermission);
        EntityPermission getPermission = reponsitoryPermission.findEntityPermissionByName(requestPermission.getName());
        if (getPermission != null)return new Responses(false, ResponseString.WRONG_NAME);
        entityPermission.setName(requestPermission.getName());
        reponsitoryPermission.save(entityPermission);
        return new Responses(true,ResponseString.SUCCESS,entityPermission);
    }

    @Override
    public Responses updatePermission(RequestUpdatePermission requestUpdatePermission, Integer id) {
        EntityPermission entityPermission = reponsitoryPermission.findEntityPermissionById(id);
        if (entityPermission == null)return  new Responses(false,ResponseString.WRONG_ID);
        entityPermission.setDescription(requestUpdatePermission.getDescription());
        reponsitoryPermission.save(entityPermission);
        return new Responses(true,ResponseString.SUCCESS,entityPermission);
    }

    @Override
    public Responses deletePermission(Integer id) {
        EntityPermission entityPermission = reponsitoryPermission.findEntityPermissionById(id);
        if (entityPermission == null)return  new Responses(false,ResponseString.WRONG_ID);
        reponsitoryPermission.deleteById(id);
        return new Responses(true,ResponseString.SUCCESS,entityPermission);
    }
}
