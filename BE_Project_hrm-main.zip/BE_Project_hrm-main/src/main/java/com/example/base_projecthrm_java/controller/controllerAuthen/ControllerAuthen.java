package com.example.base_projecthrm_java.controller.controllerAuthen;


import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestLogin;
import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestRegisterApp;
import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestRegisterWeb;
import com.example.base_projecthrm_java.services.servicesAuthen.serviceAuthen;
import com.example.base_projecthrm_java.utils.apiContants.ApiContants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@CrossOrigin("*")
public class ControllerAuthen {
    @Autowired
    private serviceAuthen serviceAuthen;
    @PreAuthorize("hasRole('User')")
@GetMapping(ApiContants.Test)
    public ResponseEntity<?> test(@RequestHeader ("Authorization") String ath){
return ResponseEntity.status(HttpStatus.OK).body(ath);
}

@PostMapping(ApiContants.Authen.REGISTERAPP)
    public ResponseEntity<?> registerAPP(@RequestBody RequestRegisterApp requestRegisterApp){
    return ResponseEntity.status(HttpStatus.OK).body(serviceAuthen.registerApp(requestRegisterApp));
}
@PostMapping(ApiContants.Authen.LOGIN)
    public ResponseEntity<?>login(@RequestBody RequestLogin requestLogin){
    return ResponseEntity.status(HttpStatus.OK).body(serviceAuthen.login(requestLogin));
}
    @PostMapping(ApiContants.Authen.REGISTERWEB)
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<?> registerWeb(@RequestBody RequestRegisterWeb requestRegisterWeb){
        return ResponseEntity.status(HttpStatus.OK).body(serviceAuthen.registerWeb(requestRegisterWeb));
    }
}
