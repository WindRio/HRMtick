package com.example.base_projecthrm_java.model.modelAuthen.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestRegisterApp {
    private String email;
    private String password;
    private Integer phone;
    private String fullName;
    private Integer presenter;
}
