package com.example.base_projecthrm_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
@CrossOrigin("*")
public class BaseProjectHrmJavaApplication {
    public static void main(String[] args) {
        SpringApplication.run(BaseProjectHrmJavaApplication.class, args);
    }

}
