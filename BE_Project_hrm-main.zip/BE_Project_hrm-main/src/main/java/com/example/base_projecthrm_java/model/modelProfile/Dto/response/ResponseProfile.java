package com.example.base_projecthrm_java.model.modelProfile.Dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseProfile {
    private Integer id;
    private String fullName;
    private Integer phone;
    private String gender;
    private String address;
    private Date birthday;
    private Integer referralCode;
    private Integer presenterCode;
}
