package com.example.base_projecthrm_java.model.modelAuthen.mapper;

import com.example.base_projecthrm_java.model.modelAuthen.dto.response.ResponseAccount;
import com.example.base_projecthrm_java.model.modelAuthen.dto.response.ResponseLogin;
import com.example.base_projecthrm_java.model.modelAuthen.entity.EntityAccount;
import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestRegisterWeb;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MapperAuthen {
    public  static ResponseAccount mapEntityAccount(EntityAccount entityAccount){
//        System.out.println("aaaaaaaaaaaaaaaaa"+entityAccount.getId()+entityAccount.getEmail()+entityAccount.isActive()+entityAccount.getListRole()+entityAccount.getProfile().getId());
//        DtoAccount dtoAccount = new DtoAccount(entityAccount.getId(),entityAccount.getEmail(),
//        entityAccount.isActive(),entityAccount.getListRole(),entityAccount.getProfile().getId());
        ResponseAccount dtoAccount = new ResponseAccount(entityAccount.getId(),entityAccount.getEmail(),entityAccount.isActive(),entityAccount.getListRole()
               );
        if (entityAccount.getProfile()!= null)dtoAccount.setIdProfile(entityAccount.getProfile().getId());
//        System.out.println("dtoAccount"+ entityAccount.getProfile());
        return dtoAccount;
    }
    public static EntityAccount mapRegister(String email){
        EntityAccount entityAccount = new EntityAccount(email);
        return entityAccount;
    }
    public static ResponseLogin mapEntityAccount_DtoLogin(EntityAccount entityAccount, String token){
        ResponseLogin dtoLogin = new ResponseLogin(entityAccount.getId(),entityAccount.getEmail(),entityAccount.getListRole(),token);
        return dtoLogin;
    }
    public static EntityAccount mapRequestRegisterWeb(RequestRegisterWeb requestRegisterWeb){
        EntityAccount entityAccount = new EntityAccount(requestRegisterWeb.getEmail());
        return entityAccount;
    }
}
