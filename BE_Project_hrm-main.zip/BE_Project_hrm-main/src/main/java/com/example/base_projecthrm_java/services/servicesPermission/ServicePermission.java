package com.example.base_projecthrm_java.services.servicesPermission;

import com.example.base_projecthrm_java.model.modelPermission.dto.request.RequestAddPermission;
import com.example.base_projecthrm_java.model.modelPermission.dto.request.RequestUpdatePermission;
//import com.example.base_projecthrm_java.model.modelPermission.response.ResponsePermission;
import com.example.base_projecthrm_java.model.response.Responses;
import org.springframework.stereotype.Service;

@Service
public interface ServicePermission {
    Responses getAllPermission();
    Responses searchPaginationPermission(String text,Integer page , Integer limit);
    Responses addPermission(RequestAddPermission requestPermission);
    Responses updatePermission(RequestUpdatePermission requestUpdatePermission, Integer id);
    Responses deletePermission(Integer id);
}
