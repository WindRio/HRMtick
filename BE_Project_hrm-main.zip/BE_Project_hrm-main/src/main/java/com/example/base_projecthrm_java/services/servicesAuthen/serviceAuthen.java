package com.example.base_projecthrm_java.services.servicesAuthen;

import com.example.base_projecthrm_java.model.modelAuthen.dto.request.*;
//import com.example.base_projecthrm_java.model.modelAuthen.request.*;
import com.example.base_projecthrm_java.model.response.Responses;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public interface serviceAuthen {
        Responses registerApp(RequestRegisterApp requestRegisterApp);
        Responses login(RequestLogin requestLogin);
        public UserDetails loadUserByEmail(String email );
        Responses changePasswordLogin(ChangePassword changePassword);
        Responses forgotPassword (RequestForgotPassword requestforgotPassword);
        Responses registerWeb(RequestRegisterWeb requestRegisterWeb);
//        ResponseAuthen registerWeb(RequestRegisterApp requestRegisterApp);
}
