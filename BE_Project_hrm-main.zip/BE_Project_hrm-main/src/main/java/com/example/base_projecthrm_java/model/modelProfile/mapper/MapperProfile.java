package com.example.base_projecthrm_java.model.modelProfile.mapper;

import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestRegisterApp;
import com.example.base_projecthrm_java.model.modelProfile.Dto.request.RequestProfile;
import com.example.base_projecthrm_java.model.modelProfile.Dto.response.ResponseProfile;
import com.example.base_projecthrm_java.model.modelProfile.entity.EntityProfile;

public class MapperProfile {
    public  static EntityProfile mapRequestLoginApp(RequestRegisterApp requestLoginApp){
        EntityProfile entityProfile = new EntityProfile(requestLoginApp.getFullName(), requestLoginApp.getPhone());
        return  entityProfile;
    }
    public static EntityProfile mapRequestProfile(RequestProfile requestProfile){
        EntityProfile entityProfile = new EntityProfile(requestProfile.getFullName(), requestProfile.getPhone(),
                requestProfile.getAddress(), requestProfile.getBirthday());
        return entityProfile;
    }
    public static ResponseProfile mapEntityProfile(EntityProfile entityProfile){
        ResponseProfile responseProfile  = new ResponseProfile(entityProfile.getId(),entityProfile.getFullName(), entityProfile.getPhone(), entityProfile.getGender(), entityProfile.getAddress(),
                entityProfile.getBirthday(), entityProfile.getReferralCode(), entityProfile.getPresenterCode());
        return responseProfile;
    }
}
