package com.example.base_projecthrm_java.model.modelPermission.mapper;

import com.example.base_projecthrm_java.model.modelPermission.dto.response.ResponsePermission;
import com.example.base_projecthrm_java.model.modelPermission.entity.EntityPermission;
import com.example.base_projecthrm_java.model.modelPermission.dto.request.RequestAddPermission;

public class MapperPermission {

    public  static EntityPermission mapRequestPermission(RequestAddPermission requestPermission){
        EntityPermission entityPermission = new EntityPermission(requestPermission.getDescription());
        return  entityPermission;
    }
    public static ResponsePermission mapEntityPermission (EntityPermission entityPermission){
        ResponsePermission dtoPermission =  new ResponsePermission(entityPermission.getId(), entityPermission.getName(), entityPermission.getDescription());
        return dtoPermission;
    }
}
