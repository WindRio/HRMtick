package com.example.base_projecthrm_java.services.servicesAuthen.servicesAccount;

import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestAccount;
import com.example.base_projecthrm_java.model.response.Responses;
import org.springframework.stereotype.Service;

@Service
public interface ServiceAccount {
    Responses updateAccountRole(RequestAccount requestAccount,Integer id);
    Responses searchPaginationAccount(String text, Integer page , Integer limit);
}
