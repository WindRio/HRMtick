package com.example.base_projecthrm_java.services.servicesAuthen.servicesAccount;

import com.example.base_projecthrm_java.model.modelAuthen.dto.response.ResponseAccount;
import com.example.base_projecthrm_java.model.modelAuthen.entity.EntityAccount;
import com.example.base_projecthrm_java.model.modelAuthen.mapper.MapperAuthen;
import com.example.base_projecthrm_java.model.modelAuthen.dto.request.RequestAccount;
import com.example.base_projecthrm_java.model.modelRole.entity.EntityRole;
import com.example.base_projecthrm_java.model.response.Responses;
import com.example.base_projecthrm_java.reponsitory.reponsitoryAuthen.RepositoryAccount;
import com.example.base_projecthrm_java.reponsitory.reponsitoryRole.RepositoryRole;
import com.example.base_projecthrm_java.utils.responseString.ResponseString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class ServicesAcountImp implements ServiceAccount{
    @Autowired
    private RepositoryAccount reponsitoryAccount;
    @Autowired
    private RepositoryRole reponsitoryRole;
    @Override
    public Responses updateAccountRole(RequestAccount requestAccount,Integer id) {
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountById(id);

        if (entityAccount == null)return new Responses(false, ResponseString.WRONG_ID);
//        if (requestAccount.isActive() != null)
        System.out.println("requestAccount.isActive()"+requestAccount.isActive());
        entityAccount.setActive(requestAccount.isActive());
        if (requestAccount.getListIdRole() !=null){
            Set<EntityRole> listNew = new HashSet<>() ;
            for (Integer idRole:requestAccount.getListIdRole()) {
                EntityRole entityRole =reponsitoryRole.findEntityRoleById(idRole);
                if (entityRole != null) listNew.add(entityRole);
            }
            entityAccount.setListRole(listNew);
        }
        reponsitoryAccount.save(entityAccount);
        return new Responses(true,ResponseString.SUCCESS,entityAccount);
    }

    @Override
    public Responses searchPaginationAccount(String text, Integer page, Integer limit) {
        Pageable pageable = PageRequest.of(page, limit);
        Page<EntityAccount> listPage = reponsitoryAccount.findByEmailContaining(text, pageable);
        List<ResponseAccount> listAccount= listPage.stream().map(MapperAuthen::mapEntityAccount).collect(Collectors.toList());
        if (listAccount.isEmpty()){
            return new Responses(false, ResponseString.WRONG_LIST);
        }else {
            return new Responses(true, ResponseString.SUCCESS, listAccount, listPage.getTotalPages());
        }
    }
}
