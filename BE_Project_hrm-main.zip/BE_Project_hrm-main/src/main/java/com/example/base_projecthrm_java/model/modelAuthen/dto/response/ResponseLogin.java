package com.example.base_projecthrm_java.model.modelAuthen.dto.response;

import com.example.base_projecthrm_java.model.modelRole.entity.EntityRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseLogin {
    private Integer id;
    private String email;
    private Set<EntityRole> listRole;
    private String token;
}
