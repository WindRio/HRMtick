package com.example.base_projecthrm_java.reponsitory.reponsitoryProfile;

import com.example.base_projecthrm_java.model.modelProfile.entity.EntityProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositoryProfile extends JpaRepository<EntityProfile,Long> {
//    EntityProfile findEntityProfileByReferral_code(Integer number);
    @Query(value = "SELECT * FROM account join profile on profile.id = account.profile_id where profile.referral_code = ?1",nativeQuery = true)
    EntityProfile findEntityProfileByReferral_code(Integer number);

    EntityProfile findEntityProfileById(Integer id);
}
