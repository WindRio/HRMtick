package com.example.base_projecthrm_java.model.modelAuthen.dto.request;

import lombok.Data;

import java.util.Set;

@Data
public class RequestAccount {
    private Integer idAccount;
    private boolean active;
    private Set<Integer> listIdRole;
}
