package com.example.base_projecthrm_java.mail;


import com.example.base_projecthrm_java.model.response.Responses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import javax.mail.Address;
import javax.mail.SendFailedException;

@Component
public class MailServices {
        Logger logger = LoggerFactory.getLogger(MailServices.class);

        @Autowired
private JavaMailSender mailSender;


        public Responses sendEmail(String toEmail , Integer body) {
            SimpleMailMessage mailMessage = new SimpleMailMessage();

            mailMessage.setFrom("thinhdv.eledevo@gmail.com");
            mailMessage.setTo(toEmail);
            mailMessage.setText("mã OTP của bạn là : "+body);
            mailMessage.setSubject("mã OTP");
            try {
                mailSender.send(mailMessage);
                return new Responses(true,"vào email : " + toEmail +" lấy OTP");
            }
          catch (MailSendException me){
                return detectInvalidAddress(me);
          }

//            mailSender.send(message);
        }
    private Responses detectInvalidAddress(MailSendException me) {
        Exception[] messageExceptions = me.getMessageExceptions();
        if (messageExceptions.length > 0) {
            Exception messageException = messageExceptions[0];
            if (messageException instanceof SendFailedException) {
                SendFailedException sfe = (SendFailedException) messageException;
                Address[] invalidAddresses = sfe.getInvalidAddresses();
                StringBuilder addressStr = new StringBuilder();
                for (Address address : invalidAddresses) {
                    addressStr.append(address.toString());
                }
                logger.error("invalid address(es)：{}", addressStr);
                return new Responses(false,"địa chỉ email "+addressStr+" không hơp lệ");
            }
        }
        logger.error("exception while sending mail.", me);
        return  new Responses(false,"ngoại lệ trong khi gửi thư :"+ me);
    }
}
