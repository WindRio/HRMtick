package com.example.base_projecthrm_java.services.servicesOtp;

import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestCreateOtp;
import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestSendOtp;
import com.example.base_projecthrm_java.model.modelOtp.dto.request.RequestSendOtpChangePassword;
import com.example.base_projecthrm_java.model.response.Responses;
import org.springframework.stereotype.Service;

@Service
public interface ServiceOtp {
    Responses sendOtpRegister(RequestSendOtp requestSendOtp);
    Responses createOtp(RequestCreateOtp requestCreateOtp);
    Responses sendOtpLogin(RequestSendOtp requestSendOtp);
    Responses sendOtpChangePassword(RequestSendOtpChangePassword requestSendOtpChangePassword);
}
