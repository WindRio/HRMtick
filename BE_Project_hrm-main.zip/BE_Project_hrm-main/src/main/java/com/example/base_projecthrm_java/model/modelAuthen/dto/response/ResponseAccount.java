package com.example.base_projecthrm_java.model.modelAuthen.dto.response;

import com.example.base_projecthrm_java.model.modelRole.entity.EntityRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ResponseAccount {
    private Integer id;
    private String email;
    private boolean active;
    private Set<EntityRole> listRole = new HashSet<>();
    private Integer idProfile;

    public ResponseAccount(Integer id, String email, boolean active) {
        this.id = id;
        this.email = email;
        this.active = active;
    }

    public ResponseAccount(Integer id, String email, boolean active, Set<EntityRole> listRole) {
        this.id = id;
        this.email = email;
        this.active = active;
        this.listRole = listRole;
    }
}
