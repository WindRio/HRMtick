package com.example.base_projecthrm_java.services.servicesAuthen;

import com.example.base_projecthrm_java.jwt.JwtUntility;
import com.example.base_projecthrm_java.mail.MailServices;
import com.example.base_projecthrm_java.mail.OTP;
import com.example.base_projecthrm_java.model.modelAuthen.dto.request.*;
import com.example.base_projecthrm_java.model.modelAuthen.entity.EntityAccount;
import com.example.base_projecthrm_java.model.modelAuthen.mapper.MapperAuthen;
//import com.example.base_projecthrm_java.model.modelAuthen.request.*;
import com.example.base_projecthrm_java.model.modelProfile.entity.EntityProfile;
import com.example.base_projecthrm_java.model.modelProfile.mapper.MapperProfile;
import com.example.base_projecthrm_java.model.modelRole.entity.EntityRole;
import com.example.base_projecthrm_java.model.response.Responses;
import com.example.base_projecthrm_java.reponsitory.reponsitoryAuthen.RepositoryAccount;
import com.example.base_projecthrm_java.reponsitory.reponsitoryProfile.RepositoryProfile;
import com.example.base_projecthrm_java.reponsitory.reponsitoryRole.RepositoryRole;
import com.example.base_projecthrm_java.utils.responseString.ResponseString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class ServicesAuthenImp implements serviceAuthen {
    @Autowired
    private RepositoryRole reponsitoryRole;
    @Autowired
    private RepositoryProfile reponsitoryProfile;
    @Autowired
    private RepositoryAccount reponsitoryAccount;
    @Autowired
    private MailServices mailServices;
    @Autowired
    private JwtUntility jwtUntility;
    @Override
    public Responses registerApp(RequestRegisterApp requestRegisterApp) {
        EntityAccount getAccount = reponsitoryAccount.findEntityAccountByEmail(requestRegisterApp.getEmail());
        if (getAccount != null) return new Responses(false, ResponseString.register.WRONG_EMAIL);
        Integer Otp = OTP.createOtp();
        Responses response = mailServices.sendEmail(requestRegisterApp.getEmail(), Otp);
        if (response.isStatus()) {
            Integer referral_code;
            do {
                referral_code = OTP.createOtp();
            } while (reponsitoryProfile.findEntityProfileByReferral_code(referral_code) != null);
            EntityProfile entityProfile = MapperProfile.mapRequestLoginApp(requestRegisterApp);
            entityProfile.setReferralCode(referral_code);
            if (requestRegisterApp.getPresenter() != null) {
                EntityAccount accountPresenter = reponsitoryAccount.findEntityAccountByReferral_code(requestRegisterApp.getPresenter());
                if (accountPresenter == null)return new Responses(false,ResponseString.register.WRONGPRESENTER);
                entityProfile.setAccountPresenter(accountPresenter);
                entityProfile.setPresenterCode(requestRegisterApp.getPresenter());
            }
            reponsitoryProfile.save(entityProfile);
            EntityAccount entityAccount = MapperAuthen.mapRegister(requestRegisterApp.getEmail());
            entityAccount.setOtp(Otp);
            EntityRole role = reponsitoryRole.findEntityRoleByName("ROLE_User");
            entityAccount.getListRole().add(role);
            entityAccount.setProfile(entityProfile);
            String BCryptPassword = BCrypt.hashpw(requestRegisterApp.getPassword(), BCrypt.gensalt(10));
            entityAccount.setPassword(BCryptPassword);
            reponsitoryAccount.save(entityAccount);
            entityProfile.setAccount(entityAccount);
            reponsitoryProfile.save(entityProfile);
        }
        return new Responses(response.isStatus(), response.getMessage());
    }

    @Override
    public Responses login(RequestLogin requestLogin) {
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(requestLogin.getEmail());
        if (entityAccount == null)return new Responses(false, ResponseString.Login.WRONG_EMAIL);
        boolean checkPassword = BCrypt.checkpw(requestLogin.getPassword(),entityAccount.getPassword());
        if (checkPassword == false)return new Responses(false,ResponseString.Login.WRONG_PASSWORD);
        if(entityAccount.isActive()== false)return new Responses(false,ResponseString.Login.WRONG_ACCOUNT);
        Integer Otp = OTP.createOtp();
        entityAccount.setOtp(Otp);
        reponsitoryAccount.save(entityAccount);
        Responses response = mailServices.sendEmail(entityAccount.getEmail(), Otp);
        return new Responses(response.isStatus(),response.getMessage());
    }
    @Override
    public UserDetails loadUserByEmail(String email ) throws UsernameNotFoundException{
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(email);
        if (entityAccount == null) {
            throw new UsernameNotFoundException("email :" + email + "không thấy trong DB");
        }
        List<GrantedAuthority> grantedAuthorityList = new ArrayList<>();
        for (EntityRole role : entityAccount.getListRole()) {
            GrantedAuthority grantedAuthority = new SimpleGrantedAuthority(role.getName());
            grantedAuthorityList.add(grantedAuthority);
        }
        return new org.springframework.security.core.userdetails.User(entityAccount.getEmail(), entityAccount.getPassword(), grantedAuthorityList);
    }

    @Override
    public Responses changePasswordLogin(ChangePassword changePassword) {
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(changePassword.getEmail());
        if (entityAccount==null)return new Responses(false,ResponseString.changePassword.WRONG_EMAIL);
        boolean checkPassword = BCrypt.checkpw(changePassword.getPassword(),entityAccount.getPassword());
        if (checkPassword == false)return new Responses(false,ResponseString.changePassword.WRONG_PASSWORD);
        boolean checkPasswordNew = BCrypt.checkpw(changePassword.getPassword_new(),entityAccount.getPassword());
        if (checkPasswordNew == true)return  new Responses(false,ResponseString.changePassword.WRONG_PASSWORDNEW);
        return changePassword(changePassword.getEmail(), changePassword.getPassword_new());
    }

    @Override
    public Responses forgotPassword(RequestForgotPassword requestforgotPassword) {
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(requestforgotPassword.getEmail());
        if (entityAccount == null) return new Responses(false,ResponseString.changePassword.WRONG_EMAIL);
        Integer Otp = OTP.createOtp();
        entityAccount.setOtp(Otp);
        reponsitoryAccount.save(entityAccount);
        Responses response = mailServices.sendEmail(entityAccount.getEmail(), Otp);
        return new Responses(response.isStatus(),response.getMessage());
    }

    @Override
    public Responses registerWeb(RequestRegisterWeb requestRegisterWeb) {
        EntityAccount getAccount = reponsitoryAccount.findEntityAccountByEmail(requestRegisterWeb.getEmail());
        if (getAccount != null) return new Responses(false, ResponseString.register.WRONG_EMAIL);
        EntityAccount entityAccount = MapperAuthen.mapRegister(requestRegisterWeb.getEmail());
        String BCryptPassword = BCrypt.hashpw(requestRegisterWeb.getPassword(), BCrypt.gensalt(10));
        entityAccount.setPassword(BCryptPassword);
        EntityProfile entityProfile = new EntityProfile();
        Integer referral_code;
        do {
            referral_code = OTP.createOtp();
        } while (reponsitoryProfile.findEntityProfileByReferral_code(referral_code) != null);
        entityProfile.setReferralCode(referral_code);
        reponsitoryProfile.save(entityProfile);
        entityAccount.setProfile(entityProfile);
        if (requestRegisterWeb.getListIdRole() !=null){
            Set<EntityRole> listNew = new HashSet<>() ;
            for (Integer id:requestRegisterWeb.getListIdRole()) {
                EntityRole entityRole =reponsitoryRole.findEntityRoleById(id);
                if (entityRole != null) listNew.add(entityRole);
            }
            entityAccount.setListRole(listNew);
        }
        reponsitoryAccount.save(entityAccount);
        entityProfile.setAccount(entityAccount);
        reponsitoryProfile.save(entityProfile);
        return new Responses(true,ResponseString.SUCCESS,entityAccount);
    }

    public Responses changePassword(String email,String password){
        EntityAccount entityAccount = reponsitoryAccount.findEntityAccountByEmail(email);
        if (entityAccount==null)return new Responses(false,ResponseString.changePassword.WRONG_EMAIL);
        boolean checkPassword = BCrypt.checkpw(password,entityAccount.getPassword());
        if (checkPassword==true)return new Responses(false,ResponseString.changePassword.WRONG_PASSWORDNEW);
        String BCryptPassword = BCrypt.hashpw(password, BCrypt.gensalt(10));
        entityAccount.setPassword(BCryptPassword);
        reponsitoryAccount.save(entityAccount);
        return new Responses(true,ResponseString.changePassword.CHANGEPASSWORD);
    }
}
