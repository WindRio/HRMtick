package com.example.base_projecthrm_java.controller.controllerRole;


import com.example.base_projecthrm_java.model.modelRole.dto.request.RequestRole;
import com.example.base_projecthrm_java.services.servicesRole.ServiceRole;
import com.example.base_projecthrm_java.utils.apiContants.ApiContants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@CrossOrigin("*")
@RequestMapping(ApiContants.Role)
public class ControllerRole {
    @Autowired
    private ServiceRole serviceRole;
    @GetMapping(ApiContants.getAll)
    ResponseEntity<?> getAllRole(){
        return ResponseEntity.status(HttpStatus.OK).body(serviceRole.getAllRole());
    }
    @GetMapping()
    ResponseEntity<?> searchPaginationRole(@RequestParam(name = "textSearch",defaultValue = "")String text,
                                       @RequestParam(name = "activePage",defaultValue = "0")Integer page,
                                       @RequestParam(name = "limit",defaultValue = "2")Integer limit){
        return ResponseEntity.status(HttpStatus.OK).body(serviceRole.searchPaginationRole(text,page,limit));
    }
    @PostMapping()
    ResponseEntity<?>addRole(@RequestBody RequestRole requestRole){
        return ResponseEntity.status(HttpStatus.OK).body(serviceRole.addRole(requestRole));
    }
    @PutMapping("{id}")
    ResponseEntity<?>updateRole(@RequestBody RequestRole requestRole,@PathVariable Integer id){
        return ResponseEntity.status(HttpStatus.OK).body(serviceRole.updateRole(requestRole,id));
    }
    @DeleteMapping ("{id}")
    ResponseEntity<?>deleteRole(@PathVariable Integer id){
        return ResponseEntity.status(HttpStatus.OK).body(serviceRole.deleteRole(id));
    }
}
